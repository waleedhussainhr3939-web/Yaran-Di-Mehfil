YARAN DI MEHFIL — website preview

HOW TO VIEW
1. Extract the ZIP file.
2. Open the folder.
3. Double-click index.html to open it in Chrome or Edge.

WHAT'S INCLUDED
- Responsive black and red gaming-inspired design
- Animated hero background and hover effects
- About, member, gallery, memories and admin sections
- Join form with date-of-birth 18+ eligibility check

IMPORTANT
This is a front-end preview. The join form does not send or store applications.
The members, gallery, videos and chat are not connected to a server yet.
Real group chat, private messages, member accounts, admin approvals, uploads,
and secure age/identity verification require a backend/database and hosting.
This demo does not use face scanning or collect biometric data.
